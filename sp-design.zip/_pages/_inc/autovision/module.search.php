<?
if ($_REQUEST['_get_block'] or $_SYSTEM->REQUESTED_PAGE != '/search.html') {
	//если ajax-запрос, то выполняем поиск

	require_once(__spellPATH("USER_CLASS:/autoresource/autoshop/class.LOCAL_SearchModule.php"));

} else {

	//иначе создаем класс-пустышку для генерации ajax-запроса
	global $__BUFFER;

	$__BUFFER->addScript('/_syslib/class.TabLister.js');
	$__BUFFER->addCSS('/_syslib/squeezebox/squeezebox_info.css');
	$__BUFFER->addScript('/_syslib/squeezebox/squeezebox.js');

	class LOCAL_SearchModule {

		/**
		 * пустая функция объявлена ибо она вызывается в callModule
		 * @param null $externalParams
		 */
		function Process($externalParams = NULL) {

			return;

		}

		/**
		 * выводим информационное окно, а потом запускаем ajax-запрос на поиск
		 * @param $render
		 * @param $template
		 */
		function render($render, $template) { ?>

			<div id="main_inner_wrapper"></div>

			<script type="text/javascript">

				function ajaxSearch(url) {

					$('main_inner_wrapper').set('html', '<div id="main_inner_div"><img src="/images/ajax-loader-big.gif" alt="Идет сбор информации по базе данных" title="Идет сбор информации по базе данных"/><br/><br/>Идет сбор информации по базе данных</div>');

					new Request({
						'url': <? if(!empty($_GET)){?> url + '&_get_block=1'<?} else {?> url + '?_get_block=1'<?}?>,
						'method': 'get',
						'evalScripts': true,
						onSuccess: function (responseText) {

							responseText = responseText.replace(new RegExp('&_get_block=1', 'g'), '');
							$('main_inner_wrapper').set('html', responseText);
							$$('#main_inner_wrapper a[href^=/search.html]').addEvent('click', function (el) {

								ajaxSearch(this.href);
								return false;

							});

						}
					}).send();

				}

				window.addEvent('load', function () {
					ajaxSearch('<?=$_SERVER['REQUEST_URI']?>')
				});

			</script>

		<? }

	}

}