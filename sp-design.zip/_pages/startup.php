<? ContentPart("startup_text");
include(__spellPATH("/ar2/catalogs.php"));