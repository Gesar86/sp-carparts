<?=$MSG['AccessDenied']['msg1']?>
<?=$MSG['AccessDenied']['msg2']?>