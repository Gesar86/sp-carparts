<?
$stocks = $_interface->API->getStocksList();
if (count($stocks) > 0) {
	foreach ($stocks as $stock) { ?>
		<div class="stock">
			<span>г. <?=$stock['cty_name']?></span>
			<?=$stock['stc_name']?>, тел. <?=$stock['stc_phone']?>
		</div>
	<? }
}