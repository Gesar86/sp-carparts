	<div id="footer_inner">
		<div id="footer_cars">
			<div class="rcar" style="right:0%"><img src="/images/cars/footer/cars/car1.png" alt=""></div>
				<div class="rcar" style="right:18%"><img src="/images/cars/footer/acs/acs1.png" alt=""></div>
				<div class="rcar" style="right:36%"><img src="/images/cars/footer/cars/car2.png" alt=""></div>
				<div class="rcar" style="right:54%"><img src="/images/cars/footer/acs/acs4.png" alt=""></div>
				<div class="rcar" style="right:72%"><img src="/images/cars/footer/cars/car4.png" alt=""></div>
				<div class="rcar" style="left:0px;"><img src="/images/cars/footer/acs/acs2.png" alt=""></div>	
			</div>
		<div id="footer_bottom" class="flc">
			<div class="leftside copy">
				<?	ContentPart('footer_left');	?>
				<?	echo $CONST["copy"]; ?>
			</div>
			<div class="rightside">
				<div class="payments flc">
					<div class="leftside">
						Способы оплаты:
					</div>
					<div class="rightside">
						<div class="pimages flc">
							<div class="leftside">
								<img src="/_sysimg/payment-sys/beznal.png" alt="Безналичный расчёт" title="Безналичный расчёт" />
								<img src="/_sysimg/payment-sys/nal.png" alt="Наличный расчёт" title="Наличный расчёт" />
							</div>
							<? $payments = $_interface->API->getOnlinePaymentsList(); ?>
							<?	$i = 0;
								$pcount = count($payments);
								if ($pcount > 0) { ?>
									<div class="leftside">
										<img src="/_sysimg/payment-sys/visa.png" alt="VISA" title="VISA" />
										<img src="/_sysimg/payment-sys/mastercard.png" alt="MasterCard" title="MasterCard" />
									</div>
									<div class="leftside">
								<?
									foreach($payments as $payment) {
										if (empty($payment['pmk_img'])) continue;
										?>
										<img src="<?=$payment['pmk_img']?>" alt="<?=$payment['pmk_name']?>" title="<?=$payment['pmk_name']?>" />
										<?
										if ($i%2 == 1) {
											echo'</div><div class="leftside">';
										}
										$i++;
									}
								?>
								</div>
							<? } ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>