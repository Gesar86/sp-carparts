<form name="search_code" action="/search.html" method="GET" onsubmit="return validate_search_code_form(this)">
	<div id="search_caption" class="flc">
		<div class="leftside">
			Поиск автозапчасти по коду
		</div>
		<div class="rightside">
			<a id="bs_simple" href="#" onclick="return false;" class="bs">простой</a> <a id="bs_full" href="#" onclick="return false;" class="bs bs_active">подробный</a>
		</div>
	</div>
	<div id="search_line" class="flc">
		<div class="rightside">
			<div id="search_buttons" class="flc">
				<div class="leftside"><input type="image" src="/images/btn_search.png" /></div>
				
				<div id="slinks" class="rightside">
					<div class="flc">
						<a href="#" style="background-image:url(/images/sf_help.png)" class="rightside m0"><span>Помощь</span></a>
						<a href="/vin/form.html" style="background-image:url(/images/sf_vin.png)" class="rightside"><span>VIN-запрос</span></a>
					</div>
				</div>
				<script type="text/javascript">
					window.addEvent('domready', function() {
						var lwidth = getWidthForce($('search_buttons')) - 75;
						$('slinks').set('styles', {
							'width':lwidth+'px',
							'margin': '0 auto'
						});
						$$('#slinks .flc').set('styles', {
							'width':'195px',
							'margin': '0 auto'
						});
					});
				</script>
			</div>
		</div>
		<? 
		$show_history = false;
		if ($auth_client) { 
			$search_stat = $_interface->API->getSearchStat($client->sourceId, 20);
			if (count($search_stat) > 0) {
				$show_history = true;
			}
		}
		?>
		<div id="search_input" class="<?=($show_history?'search_input_auth':'')?>">
			<? $empty_text = 'Например, VM12-89'; ?>
			<input class="TextBox<?=(empty($_REQUEST['article'])?'_empty':'')?>" type="text" name="article" value="<?=(empty($_REQUEST['article'])?$empty_text:htmlspecialchars($_REQUEST['article'], ENT_QUOTES))?>" onfocus="if (this.value == '<?=$empty_text?>') {this.value = ''; this.className = 'TextBox_focus';}" onblur="if (this.value == '') {this.value = '<?=$empty_text?>'; this.className = 'TextBox_empty';} else {this.className = 'TextBox';}" />
			
			<? if ($show_history) { ?>
							<div id="user_history" class="leftside">
								<div id="user_articles_div" class="flc">
									<ul id="user_articles" class="slide_menu">
										<li class="menu" id="uh_lim"><a href="#" onclick="return false;" title="Вы искали"></a>
											<ul class="article_links">
												<li class="flc">
													<? $i = 0; ?>
													<? foreach($search_stat as $key=>$item) { ?>
														<a href="/search.html?article=<?=$item['sse_search_number']?>&sort___search_results_by=final_price&smode=A" class="<?=($i%2==0?'la':'ra')?>"><span><?=$item['sse_search_number']?></span></a>
																		
														<? if (($i%2 == 1) && ($i!=0)) { ?>
															</li><li class="flc">
														<? } ?>
														<? $i++; ?>
													<? } ?>
												</li>
											</ul>
										</li>
									</ul>
									<script type="text/javascript">
										window.addEvent('domready', function() {
											var alc = 0;
											$$('a.la span').each(function(el){
												if (alc < getWidthForce(el)) {
													alc = getWidthForce(el);
												}
											});
											var arc = 0;
											$$('a.ra span').each(function(el){
												if (arc < getWidthForce(el)) {
													arc = getWidthForce(el);
												}
											});
											
											while (alc+arc < 70) {
												alc++;
												arc++;
											}
											
											$$('a.la').set('styles', {
												'width':alc+'px'
											});
											$$('a.ra').set('styles', {
												'width':arc+'px'
											});
											
											var myMenu = new MenuMatic({
												id:'user_articles',
												subMenusContainerId: 'subMenusContainerHistory',
												opacity:'100',
												onShowSubMenu_begin: function(subMenuClass){
													$('uh_lim').addClass('menu_act');
												},
												onHideSubMenu_complete: function(subMenuClass){
													$('uh_lim').removeClass('menu_act');
												}
											});
											
										}); 
									</script>
								</div>
							</div>
					<? } ?>
		</div>
		<div id="search_full">
			<div class="bs_div"></div>
			<div id="search_full_inner" class="bs_div"><div class="fake_search_flc"></div>
				<div class="flc">
					<? $smode = ($_REQUEST['smode'] == 'A0'?'A0':'A')?>
					<script type="text/javascript">
						function check_smode(el) {
							if (el.checked) {
								$('smode').value = 'A';
							} else {
								$('smode').value = 'A0';
							}							
						}
						
						window.addEvent('domready', function () {
							showSort();
						});
						function showSort() {

							var element = $(document.body);
							var rs = element.getElements('#searchTemplate');
							var sort = element.getElements("input#sort___search_results_by");
							
							if(rs.get('value') == 'groups') {
								element.getElements("#sort_type_search").set('styles',{"display":"none"});
								sort.set('data-it',sort.get('value'));
								element.getElements("input#sort___search_results_by").set('value','final_price');
								element.getElements("#search_full").setStyle("width","600px");
							}
							else {
							
								temp = sort.get('data-it')[0];
								if(sort.get('value')!=temp && temp!=null)
									sort.set('value',temp)
									
								element.getElements("#sort_type_search").set('styles',{"display":"block"});
								element.getElements("#search_full").setStyle("width","750px");
							}
						}
						
					</script>
					
					<span>Вид результатов поиска:</span>
					
					<select id="searchTemplate" name="st" onchange="showSort()">
					<?if($_REQUEST['st']) {?> 
						<option value="default"<?=($_REQUEST['st']=='default'?' selected="selected"':'')?>>классический </option>
						<option value="groups"<?=($_REQUEST['st']=='groups'?' selected="selected"':'')?>>сгрупированный </option>
					<?} else {?>
						<option value="default"<?=($_interface->csSearchTemplate =='default'?' selected="selected"':'')?>>классический </option>
						<option value="groups"<?=($_interface->csSearchTemplate == 'groups'?' selected="selected"':'')?>>сгрупированный </option>
					<?}?>
					</select>
					
					<span>Срок поставки:</span>
					<select id="term" name="term">
						<option value="0"<?=($_REQUEST['term']=='0'?' selected="selected"':'')?>>не важен</option>
						<option value="10"<?=($_REQUEST['term']=='10'?' selected="selected"':'')?>>до 10 дней</option>
						<option value="8"<?=($_REQUEST['term']=='8'?' selected="selected"':'')?>>до 8-ми дней</option>
						<option value="5"<?=($_REQUEST['term']=='5'?' selected="selected"':'')?>>до 5 дней</option>
						<option value="3"<?=($_REQUEST['term']=='3'?' selected="selected"':'')?>>до 3-х дней</option>
						<option value="1"<?=($_REQUEST['term']=='1'?' selected="selected"':'')?>>1 день</option>
					</select>
									
					<div id="sort_type_search">
						<span>Сортировка:</span>
						<select id="sort___search_results_by" name="sort___search_results_by">
							<option value="final_price"<?=($_REQUEST['sort___search_results_by']=='final_price'?' selected="selected"':'')?>>по цене</option>
							<option value="article"<?=($_REQUEST['sort___search_results_by']=='article'?' selected="selected"':'')?>>по коду</option>
						</select>
					</div>
					<span class="last"><input type="checkbox" name="chk_smode" id="chk_smode" onclick="check_smode(this)"<?=($smode=='A'?' checked="checked"':'')?> /><label for="chk_smode">Искать аналоги</label></span>

					<input type="hidden" name="smode" id="smode" value="<?=$smode?>" />
					
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript">
		window.addEvent('domready', function() {
			var myAccordion = new Fx.Accordion($$('.bs'), $$('.bs_div'), {
				opacity: false,
				display: <?=($_COOKIE['showFullSearch']=='1'?'1':'0')?>,
				initialDisplayFx: false,
				alwaysHide: false,
				onActive: function(toggler, element){
					setTimeout(function(){if (toggler.hasClass('bs_active')) element.addClass('vis')}, 1000);
					toggler.addClass('bs_active');
					if (toggler.id == 'bs_full') {
						setCookie('showFullSearch','1');
					} else {
						setCookie('showFullSearch','0');
					}
				},
				onBackground: function(toggler, element){
					toggler.removeClass('bs_active');
					if (element.hasClass('vis')) element.removeClass('vis');
				}
			});
		});
	</script>
	<script type="text/javascript">
		function validate_search_code_form(arg) {
			if (arg.article.value == '<?=$empty_text?>') arg.article.value = '';
			if (arg && trim(arg.article.value) == '' && isElementVisible(arg.article)) {
				alert('Пожалуйста, укажите значение поля "артикул"');
				arg.article.focus();
				return false;
			}
			return true;
		}
	</script>
</form>