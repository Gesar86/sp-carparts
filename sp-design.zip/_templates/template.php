<?
$currencies = $client->Interface->getCurrencyRate();
$curUSD = number_format((float)$currencies[2]['crt_rate'], 2, '.', ' ');
$curEURO = number_format((float)$currencies[3]['crt_rate'], 2, '.', ' ');
$nativeCur = $client->Interface->nativeCurInfo;

$auth_client = ((int)$client->cst_category_id > 0 ? true : false);

$__BUFFER->AddContent('HEADER', '<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />');
$__BUFFER->AddContent('CUSTOM_HEADER', '<meta http-equiv="X-UA-Compatible" content="IE=edge">');

?>

<body id="page">

	<? require_once "_inner_templates/cars.php"; ?>

	<div id="wrapper">

		<div id="header">
			<div id="header_inner">
				<div id="top_line" class="flc">
					<div id="top_currencies" class="leftside">
						Курсы: 1$ =
						<strong><?= $curUSD ?></strong> <?= (($nativeCur['html_sign']) ? $nativeCur['html_sign'] : "руб.") ?>
						<span>|</span>1€ =
						<strong><?= $curEURO ?></strong> <?= (($nativeCur['html_sign']) ? $nativeCur['html_sign'] : "руб.") ?>
					</div>
					<div id="top_icons" class="rightside">
						<a href="/message/" class="a_feedback"></a><span>|</span><a href="/sitemap.html" class="a_sitemap"></a>
					</div>
				</div>
				<div id="header_top" class="flc">
					<div id="logo" class="leftside">
						<a href="/"><img src="/images/logo.png" alt="Веб-АвтоРесурс" title="Веб-АвтоРесурс"/></a>
					</div>
					<div id="top_contacts" class="leftside">
						<? ContentPart('top_contacts'); ?>
					</div>
					<div class="leftside" id="top_consultant">
						<span class="cons_title">Онлайн-консультант</span>
						<span class="cons_status">в сети</span>
					</div>

					<? if ($auth_client) { ?>

						<div id="user_top_links" class="rightside">
							<div class="flc">
								<a href="/shop/basket.html" style="background-image:url(/images/ti_basket.png)"><span>Корзина</span></a>
								<a href="/shop/myorders.html" style="background-image:url(/images/ti_orders.png)"><span>Мои заказы</span></a>
							</div>
						</div>

					<? } else { ?>

						<div id="user_top_links" class="rightside" style="display:<?= (!empty($client->sourceId) ? 'block' : 'none') ?>">
							<div class="flc">
								<a href="/shop/basket.html" style="background-image:url(/images/ti_basket.png)"><span>Корзина</span></a>
							</div>
						</div>

					<? } ?>
				</div>
				<div id="header_middle" class="flc">
					<div id="login_block" class="leftside">
						<?

						echo AutoResource_CallModule(
							"LoginFormModule",
							"module.login-form.php",
							"DR_PHP"
						);

						?>

						<? if ($auth_client) { ?>

							<div id="user_menu_div" class="flc">

								<? NavigationPart("user_menu", "PHP_TEMPLATES_LIB:/content/tpl.user_menu.php", "DR_PHP"); ?>

							</div>


						<? } ?>


					</div>
					<div id="search_block">
						<div id="search_block_inner">
							<div id="top_cars">
								<? getCars('top',3,150, 190); ?>
							</div>
							<div id="search_form">
								<div id="sf_shad"></div>
								<? require_once "_inner_templates/search.php"; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div id="middle">
			<div id="container">
				<div id="content">
					<div id="content_inner">

						<? require_once(__spellPATH($_SYSTEM->LOADPAGE)); ?>

						<? if (in_array($_SYSTEM->REQUESTED_PAGE, array('/', '/tyres_discs_search/'))) { ?>
							<div id="act_news" class="flc">

								<? ContentPart("actions", "PHP_TEMPLATES_LIB:/content/tpl.actions-startup.php", "DR_PHP"); ?>

								<? ContentPart("news", "PHP_TEMPLATES_LIB:/content/tpl.news-startup.php", "DR_PHP"); ?>

							</div>
						<? } ?>
					</div>
				</div>
			</div>

			<div class="sidebar" id="sideLeft">

				<div id="left_menu">
					<? NavigationPart("left_menu", "PHP_TEMPLATES_LIB:/content/tpl.left_menu.php", "DR_PHP"); ?>
				</div>

				<div id="left_stocks">
					<div class="sb_caption">Наши магазины:</div>
					<? require_once "_inner_templates/stocks_list.php"; ?>
				</div>

			</div>
		</div>

	</div>

	<div id="footer">
		<? require_once "_inner_templates/footer.php"; ?>
	</div>

</body>