<body leftmargin="0" topmargin="0" marginheight="0" marginwidth="0">
<?
	require_once(__spellPATH($_SYSTEM->LOADPAGE));
?>
</body>